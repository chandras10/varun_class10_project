package demo.core;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;



public class SnakeNLadderTest {

	public static void main(String[] args) {
		SnakeNLadder s = new SnakeNLadder();
		s.startGame();

	}

}

