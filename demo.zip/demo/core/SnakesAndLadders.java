package demo.core;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class SnakesAndLadders
{
    
    public void paintComponent(Graphics g) {
     
        //Image image = new ImageIcon("games-clipart-snake-ladder-10.jpg").getImage();
        //g.drawImage(image, 3, 4, this);
        
        g.setColor(Color.orange);
        g.fillRect(20, 50, 100, 100);
    }
    
}
